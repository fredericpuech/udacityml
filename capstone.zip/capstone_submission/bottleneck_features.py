from keras.preprocessing.image import ImageDataGenerator
from keras.models import Sequential
from keras.layers import Dropout, Flatten, Dense
from keras import applications
import math

# dimensions of our images.
img_width, img_height = 150, 150

train_data_dir = 'images_training_rev1/train'
valid_data_dir = 'images_training_rev1/valid'
test_data_dir = 'images_training_rev1/test'
nb_train_samples = num_train
nb_validation_samples = num_valid
nb_test_samples = num_test
epochs = 1
batch_size = 16

predict_size_train = int(math.ceil(nb_train_samples / batch_size))
predict_size_validation = int(math.ceil(nb_validation_samples / batch_size))
predict_size_test = int(math.ceil(nb_test_samples / batch_size))


def save_bottlebeck_features():
    datagen = ImageDataGenerator(rescale=1. / 255)

    # build the Xception network
    model = applications.Xception(include_top=False, weights='imagenet')
    
    train_generator_b = datagen.flow_from_directory(
        train_data_dir,
        target_size=(img_width, img_height),
        batch_size=batch_size,
        class_mode='categorical',
        shuffle=False)
    bottleneck_features_train = model.predict_generator(
        train_generator_b, predict_size_train)
    np.save('bottleneck_features_train.npy', bottleneck_features_train)

    valid_generator_b = datagen.flow_from_directory(
        valid_data_dir,
        target_size=(img_width, img_height),
        batch_size=batch_size,
        class_mode='categorical',
        shuffle=False)
    bottleneck_features_valid = model.predict_generator(
        valid_generator_b, predict_size_validation)
    np.save('bottleneck_features_valid.npy', bottleneck_features_valid)
 
    test_generator_b = datagen.flow_from_directory(
        test_data_dir,
        target_size=(img_width, img_height),
        batch_size=batch_size,
        class_mode='categorical',
        shuffle=False)
    bottleneck_features_test = model.predict_generator(
        test_generator_b, predict_size_test)
    np.save('bottleneck_features_test.npy', bottleneck_features_test)


save_bottlebeck_features()
