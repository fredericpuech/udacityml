# This file was created to prepare the data for the analysis
# It is meant to be executed only once, which is why it is separated from the rest of the project


import shutil
import os, os.path
import sys
from IPython.display import display
from IPython.display import Image as _Imgdis
from PIL import Image
import numpy as np
import pandas as pd
import random
from time import time
from time import sleep
from scipy import ndimage
import random


num_images = 61578 # Actual number of training images. Used to check data load

# Load labels as dataframe

labels_file = pd.read_csv("training_solutions_rev1.csv")
labels_file.columns=labels_file.columns.str.replace('.','_')
print("Working with {0} images".format(len(labels_file)))
labels_file.iloc[0:10]

# Generate random label to be used to split sample between Train, Validation and Test

random.seed=21 # fix seed to ensure reproducibility
labels_file['random'] = np.random.randint(1, 4, labels_file.shape[0])
labels_file.iloc[0:10,[0,-1]]

# Classify records based on Q1 (cf. Galaxy Zoo decision tree in my report)

labels_file["maxvalQ1"] = labels_file[["Class1_1", "Class1_2", "Class1_3"]].max(axis=1)
Label = []

for row in range(0,len(labels_file)):
    if labels_file.maxvalQ1[row] == labels_file.Class1_1[row] :
        Label.append(1)
    elif labels_file.maxvalQ1[row] == labels_file.Class1_2[row] :
        Label.append(2)
    else: 
        Label.append(3)

labels_file["Label"] = Label
labels_file.iloc[0:10,[0,1,2,3,-1]]
labels_file.to_csv("labels_file_to_use.csv", index=False) # save new dataframe as csv to be used for rest of project

# Create desired tree directory

os.mkdir('images_training_rev1/train')
os.mkdir('images_training_rev1/valid')
os.mkdir('images_training_rev1/test')
os.mkdir('images_training_rev1/train/Q1_1')
os.mkdir('images_training_rev1/train/Q1_2')
os.mkdir('images_training_rev1/train/Q1_3')
os.mkdir('images_training_rev1/valid/Q1_1')
os.mkdir('images_training_rev1/valid/Q1_2')
os.mkdir('images_training_rev1/valid/Q1_3')
os.mkdir('images_training_rev1/test/Q1_1')
os.mkdir('images_training_rev1/test/Q1_2')
os.mkdir('images_training_rev1/test/Q1_3')

# Split files between Train, Validation and Test sample (randomly generated above)

for row in range(0,len(labels_file)):
    if labels_file.random[row] == 1 :
        shutil.move("images_training_rev1/"+str(labels_file.GalaxyID[row])+".jpg",
                    "images_training_rev1/train/"+str(labels_file.GalaxyID[row])+".jpg")
    elif labels_file.random[row] == 2 :
        shutil.move("images_training_rev1/"+str(labels_file.GalaxyID[row])+".jpg", 
                    "images_training_rev1/valid/"+str(labels_file.GalaxyID[row])+".jpg")
    else:
        shutil.move("images_training_rev1/"+str(labels_file.GalaxyID[row])+".jpg", 
                    "images_training_rev1/test/"+str(labels_file.GalaxyID[row])+".jpg")

# Then move files to sub-directories by class

for row in range(0, len(labels_file)):
    if labels_file.random[row] == 1 :
        if labels_file.Label[row] == 1 :
            shutil.move("images_training_rev1/train/"+str(labels_file.GalaxyID[row])+".jpg",
                        "images_training_rev1/train/Q1_1/"+str(labels_file.GalaxyID[row])+".jpg")
        elif labels_file.Label[row] == 2 :
            shutil.move("images_training_rev1/train/"+str(labels_file.GalaxyID[row])+".jpg",
                        "images_training_rev1/train/Q1_2/"+str(labels_file.GalaxyID[row])+".jpg")
        else:
            shutil.move("images_training_rev1/train/"+str(labels_file.GalaxyID[row])+".jpg",
                        "images_training_rev1/train/Q1_3/"+str(labels_file.GalaxyID[row])+".jpg")
    elif labels_file.random[row] == 2 :
        if labels_file.Label[row] == 1 :
            shutil.move("images_training_rev1/valid/"+str(labels_file.GalaxyID[row])+".jpg",
                        "images_training_rev1/valid/Q1_1/"+str(labels_file.GalaxyID[row])+".jpg")
        elif labels_file.Label[row] == 2 :
            shutil.move("images_training_rev1/valid/"+str(labels_file.GalaxyID[row])+".jpg",
                        "images_training_rev1/valid/Q1_2/"+str(labels_file.GalaxyID[row])+".jpg")
        else:
            shutil.move("images_training_rev1/valid/"+str(labels_file.GalaxyID[row])+".jpg",
                        "images_training_rev1/valid/Q1_3/"+str(labels_file.GalaxyID[row])+".jpg")
    else :
        if labels_file.Label[row] == 1 :
            shutil.move("images_training_rev1/test/"+str(labels_file.GalaxyID[row])+".jpg",
                        "images_training_rev1/test/Q1_1/"+str(labels_file.GalaxyID[row])+".jpg")
        elif labels_file.Label[row] == 2 :
            shutil.move("images_training_rev1/test/"+str(labels_file.GalaxyID[row])+".jpg",
                        "images_training_rev1/test/Q1_2/"+str(labels_file.GalaxyID[row])+".jpg")
        else:
            shutil.move("images_training_rev1/test/"+str(labels_file.GalaxyID[row])+".jpg",
                        "images_training_rev1/test/Q1_3/"+str(labels_file.GalaxyID[row])+".jpg")

# Count number of files in each directory and sub-directory

num_train_Q1_1 = len([name for name in os.listdir("images_training_rev1/train/Q1_1") 
                 if os.path.isfile(os.path.join("images_training_rev1/train/Q1_1", name))])
num_train_Q1_2 = len([name for name in os.listdir("images_training_rev1/train/Q1_2") 
                 if os.path.isfile(os.path.join("images_training_rev1/train/Q1_2", name))])
num_train_Q1_3 = len([name for name in os.listdir("images_training_rev1/train/Q1_3") 
                 if os.path.isfile(os.path.join("images_training_rev1/train/Q1_3", name))])

num_valid_Q1_1 = len([name for name in os.listdir("images_training_rev1/valid/Q1_1") 
                 if os.path.isfile(os.path.join("images_training_rev1/valid/Q1_1", name))])
num_valid_Q1_2 = len([name for name in os.listdir("images_training_rev1/valid/Q1_2") 
                 if os.path.isfile(os.path.join("images_training_rev1/valid/Q1_2", name))])
num_valid_Q1_3 = len([name for name in os.listdir("images_training_rev1/valid/Q1_3") 
                 if os.path.isfile(os.path.join("images_training_rev1/valid/Q1_3", name))])

num_test_Q1_1 = len([name for name in os.listdir("images_training_rev1/test/Q1_1") 
                 if os.path.isfile(os.path.join("images_training_rev1/test/Q1_1", name))])
num_test_Q1_2 = len([name for name in os.listdir("images_training_rev1/test/Q1_2") 
                 if os.path.isfile(os.path.join("images_training_rev1/test/Q1_2", name))])
num_test_Q1_3 = len([name for name in os.listdir("images_training_rev1/test/Q1_3") 
                 if os.path.isfile(os.path.join("images_training_rev1/test/Q1_3", name))])

num_train = num_train_Q1_1 + num_train_Q1_2 + num_train_Q1_3
num_valid = num_valid_Q1_1 + num_valid_Q1_2 + num_valid_Q1_3
num_test = num_test_Q1_1 + num_test_Q1_2 + num_test_Q1_3
num_tot = num_train+num_valid+num_test

print('There are %d training files.' % num_train)
print('There are %d validation files.' % num_valid)
print('There are %d test files.' % num_test)
print('There are %d total files.' % num_tot)

# Prepare Benchmark data
labels_file_to_use = pd.read_csv("labels_file_to_use.csv")
benchmark_file = pd.read_csv("central_pixel_benchmark.csv")
benchmark_file['random'] = labels_file_to_use['random']
benchmark_file.columns=benchmark_file.columns.str.replace('.','_')
benchmark_file["maxvalQ1"] = benchmark_file[["Class1_1", "Class1_2", "Class1_3"]].max(axis=1)
Label = []

for row in range(0,len(benchmark_file)):
    if benchmark_file.maxvalQ1[row] == benchmark_file.Class1_1[row] :
        Label.append(1)
    elif benchmark_file.maxvalQ1[row] == benchmark_file.Class1_2[row] :
        Label.append(2)
    else: 
        Label.append(3)

benchmark_file["Label"] = Label
benchmark_file.iloc[0:10,[0,1,2,3,-1]]
benchmark_file.to_csv("benchmark_file_to_use.csv", index=False)
benchmark_file_to_use = pd.read_csv("benchmark_file_to_use.csv")


